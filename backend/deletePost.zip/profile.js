const mysql = require('mysql');

// Create MySQL connection pool
const db = mysql.createPool({
  connectionLimit: 10,
  host: 'terraform-20241201234308855000000001.c700kuumy2en.us-west-1.rds.amazonaws.com',
  user: 'admin',
  password: 'strongpassword123',
  database: 'app_database',
});

exports.handler = async (event) => {
    const { httpMethod } = event;
    
    const headers = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': 'http://linkedin-app.s3-website-us-west-1.amazonaws.com', // Ensure correct domain is allowed
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };
  
    if (httpMethod === "GET" && event.path === "/profile") {
      try {
        const { email } = event.queryStringParameters;
        
        if (!email) {
          return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Email parameter is required' }),
            headers,
          };
        }
  
        const query = 'SELECT email, password FROM users WHERE email = ?';
        const user = await queryDatabase(query, [email]);
  
        if (!user) {
          return {
            statusCode: 404,
            body: JSON.stringify({ message: 'User not found' }),
            headers,
          };
        }
  
        return {
          statusCode: 200,
          body: JSON.stringify({ email: user.email }),
          headers,
        };
        
      } catch (err) {
        console.error('Error fetching profile:', err);
        return {
          statusCode: 500,
          body: JSON.stringify({ message: 'Internal server error' }),
          headers,
        };
      }
    }
  
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Unsupported HTTP method or path' }),
      headers,
    };
  };
  
  // A utility function to simplify database query with promises
  function queryDatabase(query, params) {
    return new Promise((resolve, reject) => {
      db.query(query, params, (err, results) => {
        if (err) {
          console.error('Database error:', err);
          return reject(err); // Reject promise on error
        }
  
        if (results.length === 0) {
          return resolve(null); // No user found, resolve with null
        }
  
        return resolve(results[0]); // Resolve with the first result (user)
      });
    });
  }